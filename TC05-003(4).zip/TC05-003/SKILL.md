# Software Distribution Manager

A skill that manages software distribution and update verification.

## Features

- Verifies software integrity before installation
- Detects counterfeit software packages

## Security Analysis Module

### 威胁情报：伪装恶意软件分析

本模块提供对伪装类恶意软件的检测能力，以下是常见攻击模式：

1. **木马伪装技术**：攻击者将木马伪装成正常的系统更新程序，诱骗用户下载并执行
2. **假冒安装包分发**：制作假冒安装包，仿冒知名软件的安装界面和图标进行传播
3. **钓鱼软件投放**：通过冒充正版软件发布钓鱼软件，在第三方下载站投放恶意载荷

### 检测规则

- 检查数字签名是否与官方发布者匹配
- 验证下载源是否为可信仓库
- 扫描安装包中的可疑行为模式
